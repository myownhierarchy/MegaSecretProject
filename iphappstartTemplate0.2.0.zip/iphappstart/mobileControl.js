/**
 * Created by ThorbenHartmann on 18.04.17.
 */
window.addEventListener("load", function () {

    function setComponent() {

            if(window.innerWidth>767){
                document.getElementById("contentComponent").setAttribute("style", "display:block");
                document.getElementById("sidebarComponent").setAttribute("style", "display:none");
            } else {
                document.getElementById("sidebarComponent").setAttribute("style", "display:block");
                document.getElementById("contentComponent").setAttribute("style", "display:none");
            }
    }
    setComponent();
    window.addEventListener("resize", setComponent);

});
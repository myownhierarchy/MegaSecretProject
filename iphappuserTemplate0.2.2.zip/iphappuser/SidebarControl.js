/**
 * Created by ThorbenHartmann on 18.04.17.
 */
window.addEventListener("load", function(){
    var button = document.getElementById("sidebar-left-button");
    var sidebar = document.getElementById("sidebar-left");
    var content = document.getElementById("content");
    function displayButton() {
        button.setAttribute("style","display: block; position: absolute;");
        sidebar.setAttribute("style","display: none;");
    }
    function displaySidebar(){
        sidebar.setAttribute("style","display: block; position: absolute;");
        button.setAttribute("style","display: none;");
    }
    function defaultView() {
        if(window.innerWidth > 767) {
            sidebar.setAttribute("style", "");
            button.setAttribute("style", "");
            button.removeEventListener("click", displaySidebar);
            sidebar.removeEventListener("click", displayButton);
            content.removeEventListener("click", displayButton);
        } else {
            button.addEventListener("click", displaySidebar);
            sidebar.addEventListener("click", displayButton);
            content.addEventListener("click", displayButton);
        }
    }
    defaultView();
    window.addEventListener("resize", defaultView);

});

